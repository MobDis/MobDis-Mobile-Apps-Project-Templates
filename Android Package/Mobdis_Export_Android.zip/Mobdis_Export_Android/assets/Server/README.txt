README

This iPhone project is meant to quickly transform a MobDis Export into a iPhone App. 

iPad Version can be found here.

This project is hosted here at: 


For this function to work, you will need to be a registered iOS Developer with access to XCode and provisioning of applications to devices. 

Requirements
	1.	Registered Apple Developer with access to Paid iOS Developer Program
	2.	XCode 3.2.5 or higher
	3.	Mac with OS 10.6.6 or higher
Process of Submitting a iOS Application
	1.	We have a sample XCode project for you to turn your MobDis Campaign into a iPhone Application. The process takes about 30 minutes.
	2.	After you have successfully complied the application on the device, you can submit the application to the Apple App Store using their submission process. The submission process can take several days to get right if you are doing it for the first time. (http://developer.apple.com/appstore/resources/submission/)

Steps 
1) Export files from your MobDis project. The files that are exported are usually named iadjs.js, index.html, publish_loading.gif, publishCSjs.js and publishstyle.css.
2) Drag the 5 files into the XCode project
3) Under Targets > MobDis > Compile Sources, you will find iadjs.js & publishCSjs.js.
4) Drag iadjs.js & publishCSjs.js to Copy Bundle Resources
5) Build and Go. The app will be installed in simulator.

To install on a iPhone and iOS, you will be need to be paid and registered iOS developer.
For more information and guide, please see here.http://developer.apple.com/ios/manage/overview/index.action